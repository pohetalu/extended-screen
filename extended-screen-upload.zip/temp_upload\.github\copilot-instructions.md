# Android Extended Screen Project

## Project Overview
Android application that allows PC to control phone via USB cable using mouse and keyboard input. The phone acts as an extended screen controlled by PC.

## Checklist
- [x] Verify that the copilot-instructions.md file in the .github directory is created.
- [x] Scaffold the Project - Android app structure and PC server created
- [x] Customize the Project - All components implemented with full functionality
- [ ] Install Required Extensions - Android Studio and Python required
- [ ] Compile the Project - Build Android app and install Python dependencies
- [ ] Create and Run Task - Run PC server and Android app
- [ ] Launch the Project - Connect via USB and test functionality
- [x] Ensure Documentation is Complete - README.md and SETUP.md created

## Development Guidelines
- Use Java/Kotlin for Android development
- Implement USB communication using Android USB API
- Handle touch event injection with accessibility services
- Create PC-side server for mouse/keyboard capture

## Project Structure
- android/ - Android app (Kotlin)
  - MainActivity.kt - Main UI
  - UsbControlService.kt - USB communication service
  - AccessibilityControlService.kt - Touch injection service
- pc-server/ - Python server for PC
  - server.py - Main server application
  - requirements.txt - Python dependencies
